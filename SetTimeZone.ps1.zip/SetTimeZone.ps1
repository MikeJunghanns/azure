Configuration SetTimeZone
{	
		tzutil /s "W. Europe Standard Time"   
}