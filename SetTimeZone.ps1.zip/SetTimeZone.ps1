Configuration SetTimeZone
{
	Node "CICOODSC"
	{
		xTimeZone TimeZoneSetting
		{
			TimeZone = "W. Europe Standard Time"
		}			
	}		
}