Configuration SetTimeZone
{
	Import-DscResource -ModuleName xTimeZone

	Node "CICOODSC"
	{
		xTimeZone TimeZoneSetting
		{
			TimeZone = "W. Europe Standard Time"
		}			
	}		
}