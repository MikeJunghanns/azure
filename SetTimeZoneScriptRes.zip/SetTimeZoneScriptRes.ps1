Configuration SetTimeZone
{
	param ($MachineName)

	Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
	
	Node $MachineName
	{
		Script PSTimeZone
		{
			SetScript = {
				tzutil.exe /s 'W. Europe Standard Time'
			}
			GetScript =  {
				return @{
					GetScript = $GetScript
					SetScript = $SetScript
					TestScript = $TestScript
					Result = "tzutil.exe /s 'W. Europe Standard Time'"
				}
			}
			TestScript = {
				$zone = tzutil.exe /g
				return ($zone -eq "W. Europe Standard Time")
			}
		}			
	}		
}
